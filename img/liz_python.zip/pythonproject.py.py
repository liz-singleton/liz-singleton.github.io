#Python Project Liz Singleton

#Import systems
import arcpy
import os

#Set workspace as user definable
arcpy.env.workspace=arcpy.GetParameterAsText(0)
arcpy.AddWarning("Workspace Created")

#Variables
coor_system=arcpy.GetParameterAsText(2)
clip_features=arcpy.GetParameterAsText(3)
out_name=arcpy.GetParameterAsText(1)

#create GDB
arcpy.CreateFileGDB_management(arcpy.env.workspace,out_name)
arcpy.AddWarning("Create File GDB Completed")

#for loop
fclist=arcpy.ListFeatureClasses()

for fc in fclist:
    output=fc.replace(".shp","_prj.shp")
    arcpy.Project_management(fc,output,coor_system)
    arcpy.AddWarning("Define Projection Completed")
    output2=output.replace("_prj.shp","_clip")
    arcpy.Clip_analysis(output,clip_features,out_name+os.path.sep+output2)
    arcpy.AddWarning("Clip Completed")
